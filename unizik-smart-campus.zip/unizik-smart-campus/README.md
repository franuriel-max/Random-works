# UNIZIK Smart Campus — Digital Companion Platform

A static, single-page front-end demo. No build step, no server — everything
(including the demo email/Google auth) runs client-side in the browser.

## Project structure

```
unizik-smart-campus/
├── public/
│   └── index.html      ← the entire site (HTML + CSS + JS)
├── vercel.json          ← headers/routing config for Vercel
├── package.json          ← lets Vercel auto-detect the project
└── .gitignore
```

## Deploy to Vercel

### Option A — Vercel CLI (fastest)
```bash
npm i -g vercel        # if you don't already have it
cd unizik-smart-campus
vercel                 # first deploy, follow the prompts
vercel --prod          # promote to production
```

### Option B — Git + Vercel dashboard
1. Push this folder to a GitHub/GitLab/Bitbucket repo.
2. Go to https://vercel.com/new and import the repo.
3. Framework Preset: **Other** (Vercel will detect the `public/` folder
   automatically since there's no build step needed).
4. Leave Build Command empty and Output Directory as `public`.
5. Click **Deploy**.

### Option C — Drag and drop
Go to https://vercel.com/new, and drag the `public` folder directly onto
the page. Vercel will deploy it as-is.

## Notes on the demo auth

Email/password and "Continue with Google" accounts are stored in the
browser's `localStorage` — there is no backend. This is intentional for
the prototype stage; everything works (sign up, sign in, sessions
persisting across reloads, sign out) but is local to each visitor's
browser and device. Swap the `saveUsers` / `saveSession` / `googleAuth`
functions inside `index.html` for real API calls (and real Google
Identity Services) when you're ready to go to production.
