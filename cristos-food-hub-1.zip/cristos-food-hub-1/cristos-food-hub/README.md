# Cristos Food Hub — Website

A mobile-first foodstore e-commerce site for Cristos Food Hub (Ifite, Unizik, Awka). Built as a static HTML/CSS/JS site — no build step, no backend required to run it.

## How to open it

Just open `index.html` in a browser, or deploy the whole folder to Netlify (drag-and-drop the folder, or connect a Git repo). Because the catalogue is loaded via `fetch()`, if you open `index.html` directly as a `file://` URL some browsers will block the JSON fetch — when testing locally, run a quick local server instead:

```
python3 -m http.server 8080
```

then visit `http://localhost:8080`.

## File structure

```
index.html              All page sections/markup
css/
  tokens.css             Design tokens (colors, type, spacing) + base styles
  header.css             Nav bar + mobile drawer
  hero.css               Hero section + the "We Stock" wheel
  sections.css           About, Why Choose Us, Delivery, Team, Testimonials
  shop.css               Product catalogue, product cards, cart drawer
  checkout.css           Checkout modal, toast notifications
  footer.css             Payment, contact, social, footer, floating WhatsApp button
js/
  icons.js               Inline SVG icon set (no external icon font needed)
  cart.js                Cart state (add/remove/qty), persisted to localStorage
  app.js                 Data loading + all page rendering + interactivity
data/
  products.json          THE PRODUCT CATALOGUE — edit this to update the shop
  config.json             Business info, delivery zones, team, testimonials, socials
assets/images/           Empty folder reserved for real product/team photos
```

## Updating the product catalogue

Open `data/products.json`. Each product looks like this:

```json
{
  "id": "rice-001",
  "name": "Premium Long Grain Rice",
  "category": "rice",
  "description": "Clean, well-sorted long grain rice...",
  "price": 1500,
  "unit": "derica",
  "image": "placeholder",
  "badge": "Bestseller",
  "inStock": true
}
```

- `id` must be unique.
- `category` must match one of the `id` values listed in the `categories` array at the top of the same file.
- `badge` is optional — omit it for no badge, or use `"Bulk Deal"` for the green badge style, anything else renders red.
- `inStock: false` shows a "Sold Out" overlay and disables the Add button.
- The site currently shows a category icon instead of a photo. To use real photos later, swap the icon markup in `productCardHTML()` (in `js/app.js`) for an `<img>` tag pointing at files you add to `assets/images/`.

To add a new category, add an entry to the `categories` array in `products.json` with an `id`, `name`, and an `icon` key. Icon keys map to icons in `js/icons.js` via `CATEGORY_ICON_MAP` — add a new mapping there if you introduce a category that doesn't fit `rice / beans / noodles / cereal / seasoning / sugar / tomato / oil / drink / basket`.

## Updating business info, delivery zones, team, testimonials, socials

All in `data/config.json`:

- `business.whatsapp` — the number used for all "Order via WhatsApp" buttons and checkout submission. Use the international format with no `+` or spaces (e.g. `2348085181348`).
- `deliveryAreas` — each zone has a `fee` (₦) and `etaMinutes`, shown in the Delivery section and used in checkout fee calculation.
- `team` / `testimonials` — replace placeholder names, bios, and quotes. Photos currently render as a generic icon; swap in `renderTeam()` in `js/app.js` for real `<img>` tags once you have headshots.
- `socials` — replace the `url` placeholders (`"#"`) with real profile links.

## WhatsApp ordering

Clicking "Order via WhatsApp" (in the hero, cart drawer, or checkout) builds a pre-filled message listing items, quantities, and totals, then opens `wa.me` with that message pre-loaded. No backend needed — it relies entirely on the WhatsApp click-to-chat URL format.

## Payment

The Payment section and checkout modal currently support "Pay on Delivery" and "Bank Transfer" as live options, with a clearly marked "Coming Soon" placeholder for Paystack card payments. When you're ready to add real Paystack checkout, that's the slot designed to hold it — wire your Paystack inline JS or redirect flow into the `.js-checkout-whatsapp-submit` flow in `js/app.js`, or add it as a third option in the `payment-method-list` in `index.html`.

## Notes on placeholders

Anything marked "Placeholder" in the data files (team bios, testimonials, social links, pickup address) is there so the site is complete and demoable today. Replace freely — no code changes needed for any of it, only JSON edits.
