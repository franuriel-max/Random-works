/* ==========================================================================
   CART STATE MANAGEMENT
   Holds cart items in memory, persists to localStorage, and notifies
   subscribers (UI) whenever it changes.
   ========================================================================== */

const Cart = (() => {
  const STORAGE_KEY = "cristos_cart_v1";
  let items = []; // [{ id, name, price, unit, qty, category }]
  const listeners = [];

  function load() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) items = JSON.parse(raw);
    } catch (e) {
      items = [];
    }
  }

  function persist() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch (e) {
      /* storage unavailable — cart still works in-memory for this session */
    }
  }

  function notify() {
    persist();
    listeners.forEach((fn) => fn(getState()));
  }

  function getState() {
    const count = items.reduce((sum, i) => sum + i.qty, 0);
    const subtotal = items.reduce((sum, i) => sum + i.qty * i.price, 0);
    return { items: [...items], count, subtotal };
  }

  function add(product, qty = 1) {
    const existing = items.find((i) => i.id === product.id);
    if (existing) {
      existing.qty += qty;
    } else {
      items.push({
        id: product.id,
        name: product.name,
        price: product.price,
        unit: product.unit,
        category: product.category,
        qty,
      });
    }
    notify();
  }

  function setQty(id, qty) {
    const existing = items.find((i) => i.id === id);
    if (!existing) return;
    if (qty <= 0) {
      remove(id);
      return;
    }
    existing.qty = qty;
    notify();
  }

  function increment(id, by = 1) {
    const existing = items.find((i) => i.id === id);
    if (existing) setQty(id, existing.qty + by);
  }

  function decrement(id, by = 1) {
    const existing = items.find((i) => i.id === id);
    if (existing) setQty(id, existing.qty - by);
  }

  function remove(id) {
    items = items.filter((i) => i.id !== id);
    notify();
  }

  function clear() {
    items = [];
    notify();
  }

  function getQty(id) {
    const existing = items.find((i) => i.id === id);
    return existing ? existing.qty : 0;
  }

  function subscribe(fn) {
    listeners.push(fn);
  }

  load();

  return { add, setQty, increment, decrement, remove, clear, getQty, getState, subscribe };
})();
