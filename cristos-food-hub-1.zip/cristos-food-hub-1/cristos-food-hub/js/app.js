/* ==========================================================================
   CRISTOS FOOD HUB — MAIN APP
   ========================================================================== */

const App = (() => {
  let config = null;
  let productData = null;
  let activeCategory = "all";
  let searchTerm = "";
  let selectedDeliveryType = "delivery"; // 'delivery' | 'pickup'
  let selectedZoneIndex = 0;

  const fmt = (n) =>
    "₦" + Number(n).toLocaleString("en-NG", { maximumFractionDigits: 0 });

  /* ---------------------------------------------------------------------- */
  /* DATA LOADING                                                           */
  /* ---------------------------------------------------------------------- */

  async function loadData() {
    const [cfgRes, prodRes] = await Promise.all([
      fetch("data/config.json"),
      fetch("data/products.json"),
    ]);
    config = await cfgRes.json();
    productData = await prodRes.json();
  }

  /* ---------------------------------------------------------------------- */
  /* RENDER: HEADER / NAV                                                   */
  /* ---------------------------------------------------------------------- */

  function renderBrandMarks() {
    document.querySelectorAll(".js-brand-name").forEach((el) => {
      el.innerHTML = `Cristos <span>Food Hub</span>`;
    });
  }

  function initNav() {
    const header = document.querySelector(".site-header");
    const toggle = document.querySelector(".nav-toggle");
    const drawer = document.querySelector(".mobile-drawer");

    window.addEventListener("scroll", () => {
      header.classList.toggle("is-scrolled", window.scrollY > 10);
    });

    toggle.addEventListener("click", () => {
      const isOpen = drawer.classList.toggle("is-open");
      toggle.setAttribute("aria-expanded", String(isOpen));
    });

    drawer.querySelectorAll("a").forEach((a) =>
      a.addEventListener("click", () => drawer.classList.remove("is-open"))
    );
  }

  /* ---------------------------------------------------------------------- */
  /* RENDER: HERO STOCK WHEEL                                               */
  /* ---------------------------------------------------------------------- */

  function renderStockWheel() {
    const wheel = document.querySelector(".js-stock-wheel");
    if (!wheel) return;
    const items = productData.categories.slice(0, 8);
    const n = items.length;
    const radius = 42; // percent of wheel box
    items.forEach((cat, i) => {
      const angle = (i / n) * 2 * Math.PI - Math.PI / 2;
      const x = 50 + radius * Math.cos(angle);
      const y = 50 + radius * Math.sin(angle);
      const el = document.createElement("div");
      el.className = "stock-wheel__item";
      el.style.left = x + "%";
      el.style.top = y + "%";
      el.innerHTML = `${icon(CATEGORY_ICON_MAP[cat.icon] || "basket")}<span>${cat.name}</span>`;
      wheel.appendChild(el);
    });
  }

  /* ---------------------------------------------------------------------- */
  /* RENDER: WHY CHOOSE US                                                  */
  /* ---------------------------------------------------------------------- */

  function renderWhyChooseUs() {
    const grid = document.querySelector(".js-feature-grid");
    if (!grid) return;
    grid.innerHTML = config.whyChooseUs
      .map(
        (f) => `
      <div class="feature-card reveal">
        <div class="icon-circle">${icon(f.icon)}</div>
        <h4>${f.title}</h4>
        <p>${f.text}</p>
      </div>`
      )
      .join("");
  }

  /* ---------------------------------------------------------------------- */
  /* RENDER: SHOP / CATALOGUE                                               */
  /* ---------------------------------------------------------------------- */

  function renderCategoryFilters() {
    const wrap = document.querySelector(".js-cat-filters");
    if (!wrap) return;
    const allChip = `<button class="cat-chip is-active" data-cat="all">${icon("basket")} All</button>`;
    const chips = productData.categories
      .map(
        (c) =>
          `<button class="cat-chip" data-cat="${c.id}">${icon(CATEGORY_ICON_MAP[c.icon] || "basket")} ${c.name}</button>`
      )
      .join("");
    wrap.innerHTML = allChip + chips;

    wrap.querySelectorAll(".cat-chip").forEach((chip) => {
      chip.addEventListener("click", () => {
        wrap.querySelectorAll(".cat-chip").forEach((c) => c.classList.remove("is-active"));
        chip.classList.add("is-active");
        activeCategory = chip.dataset.cat;
        renderProductGrid();
      });
    });
  }

  function productCardHTML(p) {
    const catIcon = productData.categories.find((c) => c.id === p.category)?.icon || "basket";
    const qty = Cart.getQty(p.id);
    const badgeHTML = p.badge
      ? `<span class="product-badge ${p.badge === "Bulk Deal" ? "bulk" : ""}">${p.badge}</span>`
      : "";
    const oosHTML = !p.inStock ? `<div class="product-oos">Out of Stock</div>` : "";
    return `
    <article class="product-card reveal" data-id="${p.id}">
      <div class="product-media">
        ${icon(CATEGORY_ICON_MAP[catIcon] || "basket")}
        ${badgeHTML}
        ${oosHTML}
      </div>
      <div class="product-info">
        <span class="product-cat-tag">${productData.categories.find((c) => c.id === p.category)?.name || ""}</span>
        <h4>${p.name}</h4>
        <p class="product-desc">${p.description}</p>
        <div class="product-price-row">
          <span class="product-price">${fmt(p.price)}</span>
          <span class="product-unit">/ ${p.unit}</span>
        </div>
        <div class="product-footer">
          <div class="qty-stepper" data-id="${p.id}">
            <button type="button" class="js-qty-minus" aria-label="Decrease quantity">−</button>
            <span class="js-qty-value">${qty || 1}</span>
            <button type="button" class="js-qty-plus" aria-label="Increase quantity">+</button>
          </div>
          <button type="button" class="add-cart-btn js-add-cart" data-id="${p.id}" ${!p.inStock ? "disabled" : ""}>
            ${icon("cart")} ${p.inStock ? "Add" : "Sold Out"}
          </button>
        </div>
      </div>
    </article>`;
  }

  function getFilteredProducts() {
    return productData.products.filter((p) => {
      const matchesCat = activeCategory === "all" || p.category === activeCategory;
      const matchesSearch =
        !searchTerm || p.name.toLowerCase().includes(searchTerm) || p.description.toLowerCase().includes(searchTerm);
      return matchesCat && matchesSearch;
    });
  }

  function renderProductGrid() {
    const grid = document.querySelector(".js-product-grid");
    if (!grid) return;
    const list = getFilteredProducts();

    if (list.length === 0) {
      grid.innerHTML = `
        <div class="empty-state" style="grid-column:1/-1">
          ${icon("search")}
          <p>No products match your search. Try a different term or category.</p>
        </div>`;
      return;
    }

    grid.innerHTML = list.map(productCardHTML).join("");
    bindProductCardEvents(grid);
    initReveal(grid);
  }

  function bindProductCardEvents(scope) {
    scope.querySelectorAll(".product-card").forEach((card) => {
      const id = card.dataset.id;
      const stepper = card.querySelector(".qty-stepper");
      const valueEl = card.querySelector(".js-qty-value");
      const minus = card.querySelector(".js-qty-minus");
      const plus = card.querySelector(".js-qty-plus");
      const addBtn = card.querySelector(".js-add-cart");

      let pendingQty = parseInt(valueEl.textContent, 10) || 1;

      plus.addEventListener("click", () => {
        pendingQty += 1;
        valueEl.textContent = pendingQty;
      });

      minus.addEventListener("click", () => {
        pendingQty = Math.max(1, pendingQty - 1);
        valueEl.textContent = pendingQty;
      });

      addBtn.addEventListener("click", () => {
        const product = productData.products.find((p) => p.id === id);
        if (!product || !product.inStock) return;
        Cart.add(product, pendingQty);
        addBtn.classList.add("is-added");
        const original = addBtn.innerHTML;
        addBtn.innerHTML = `${icon("check")} Added`;
        showToast(`${product.name} added to cart`);
        bumpCartIcon();
        setTimeout(() => {
          addBtn.classList.remove("is-added");
          addBtn.innerHTML = original;
        }, 1200);
      });
    });
  }

  function initShopSearch() {
    const input = document.querySelector(".js-shop-search");
    if (!input) return;
    input.addEventListener("input", (e) => {
      searchTerm = e.target.value.trim().toLowerCase();
      renderProductGrid();
    });
  }

  /* ---------------------------------------------------------------------- */
  /* RENDER: TEAM / TESTIMONIALS / DELIVERY / SOCIAL / CONTACT              */
  /* ---------------------------------------------------------------------- */

  function renderTeam() {
    const grid = document.querySelector(".js-team-grid");
    if (!grid) return;
    grid.innerHTML = config.team
      .map(
        (m) => `
      <div class="team-card reveal">
        <div class="team-photo">
          ${icon("user")}
          <span class="role-tag">${m.role}</span>
        </div>
        <div class="team-info">
          <span class="placeholder-flag">Placeholder photo &amp; bio</span>
          <h4>${m.name}</h4>
          <p>${m.bio}</p>
        </div>
      </div>`
      )
      .join("");
  }

  function renderTestimonials() {
    const track = document.querySelector(".js-testimonial-track");
    if (!track) return;
    track.innerHTML = config.testimonials
      .map((t) => {
        const initials = t.name
          .split(" ")
          .map((w) => w[0])
          .join("")
          .slice(0, 2);
        const stars = Array.from({ length: 5 }, (_, i) =>
          i < t.rating ? icon("star") : `<span style="opacity:.25">${icon("star")}</span>`
        ).join("");
        return `
        <div class="testimonial-card reveal">
          <div class="stars">${stars}</div>
          <p class="quote">"${t.quote}"</p>
          <div class="testimonial-person">
            <div class="testimonial-avatar">${initials}</div>
            <div>
              <strong>${t.name}</strong>
              <span>${t.role}</span>
            </div>
          </div>
        </div>`;
      })
      .join("");
  }

  function renderDelivery() {
    const list = document.querySelector(".js-delivery-zones");
    if (!list) return;
    list.innerHTML = config.deliveryAreas
      .map(
        (z) => `
      <div class="delivery-zone">
        <span class="zone-name">${icon("pin")} ${z.name}</span>
        <span class="zone-meta">
          <span class="zone-fee">${fmt(z.fee)}</span><br/>
          ~${z.etaMinutes} mins
        </span>
      </div>`
      )
      .join("");
  }

  function renderSocial() {
    const containers = document.querySelectorAll(".js-social-strip");
    if (!containers.length) return;
    const html = config.socials
      .map(
        (s) => `<a class="social-link" href="${s.url}" target="_blank" rel="noopener">${icon(s.icon)} ${s.platform}</a>`
      )
      .join("");
    containers.forEach((c) => (c.innerHTML = html));
  }

  function renderContactInfo() {
    const list = document.querySelector(".js-contact-info");
    if (!list) return;
    const b = config.business;
    list.innerHTML = `
      <div class="contact-info-item">
        <span class="icon-circle">${icon("pin")}</span>
        <div><strong>Address</strong><span>${b.address}</span></div>
      </div>
      <div class="contact-info-item">
        <span class="icon-circle">${icon("phone")}</span>
        <div><strong>Phone</strong><a href="tel:${b.phone}">${b.phone}</a></div>
      </div>
      <div class="contact-info-item">
        <span class="icon-circle">${icon("whatsapp")}</span>
        <div><strong>WhatsApp</strong><a href="https://wa.me/${b.whatsapp}" target="_blank" rel="noopener">${b.phone}</a></div>
      </div>
      <div class="contact-info-item">
        <span class="icon-circle">${icon("mail")}</span>
        <div><strong>Email</strong><a href="mailto:${b.email}">${b.email}</a></div>
      </div>
      <div class="contact-info-item">
        <span class="icon-circle">${icon("clock")}</span>
        <div><strong>Hours</strong><span>${b.hours}</span></div>
      </div>`;
  }

  function fillBusinessText() {
    const b = config.business;
    document.querySelectorAll(".js-tagline").forEach((el) => (el.textContent = b.tagline));
    document.querySelectorAll(".js-business-address").forEach((el) => (el.textContent = b.address));
    document.querySelectorAll(".js-business-phone").forEach((el) => (el.textContent = b.phone));
    document.querySelectorAll(".js-whatsapp-link").forEach((el) => (el.href = `https://wa.me/${b.whatsapp}`));
    const tagWrap = document.querySelector(".js-hero-tags");
    if (tagWrap) {
      tagWrap.innerHTML = b.tagcloud
        .map(
          (t, i) =>
            `<span class="hero-tag ${i === b.tagcloud.length - 1 ? "coin" : ""}">${icon(i === b.tagcloud.length - 1 ? "coin" : "bolt")} ${t}</span>`
        )
        .join("");
    }
  }

  /* ---------------------------------------------------------------------- */
  /* CART DRAWER                                                            */
  /* ---------------------------------------------------------------------- */

  function cartItemHTML(item) {
    const catIcon = productData.categories.find((c) => c.id === item.category)?.icon || "basket";
    return `
    <div class="cart-item" data-id="${item.id}">
      <div class="cart-item-thumb">${icon(CATEGORY_ICON_MAP[catIcon] || "basket")}</div>
      <div>
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-unit">${item.unit}</div>
        <div class="cart-item-controls">
          <div class="qty-stepper">
            <button type="button" class="js-cart-minus" aria-label="Decrease quantity">−</button>
            <span>${item.qty}</span>
            <button type="button" class="js-cart-plus" aria-label="Increase quantity">+</button>
          </div>
        </div>
      </div>
      <button type="button" class="cart-item-remove js-cart-remove" aria-label="Remove item">${icon("trash")}</button>
      <div class="cart-item-price">${fmt(item.qty * item.price)}</div>
    </div>`;
  }

  function renderCartDrawer(state) {
    const itemsWrap = document.querySelector(".js-cart-items");
    const foot = document.querySelector(".js-cart-foot");
    const countEls = document.querySelectorAll(".js-cart-count");
    const checkoutBtn = document.querySelector(".js-open-checkout");

    countEls.forEach((el) => {
      el.textContent = state.count;
      el.style.display = state.count > 0 ? "flex" : "none";
    });

    if (!itemsWrap) return;

    if (state.items.length === 0) {
      itemsWrap.innerHTML = `
        <div class="cart-empty">
          ${icon("cart")}
          <p>Your cart is empty. Add a few essentials from the shop!</p>
        </div>`;
      if (foot) foot.style.display = "none";
      if (checkoutBtn) checkoutBtn.disabled = true;
      return;
    }

    if (foot) foot.style.display = "block";
    if (checkoutBtn) checkoutBtn.disabled = false;

    itemsWrap.innerHTML = state.items.map(cartItemHTML).join("");

    itemsWrap.querySelectorAll(".cart-item").forEach((row) => {
      const id = row.dataset.id;
      row.querySelector(".js-cart-plus").addEventListener("click", () => Cart.increment(id));
      row.querySelector(".js-cart-minus").addEventListener("click", () => Cart.decrement(id));
      row.querySelector(".js-cart-remove").addEventListener("click", () => Cart.remove(id));
    });

    if (foot) {
      foot.innerHTML = `
        <div class="cart-summary-row"><span>Subtotal</span><span>${fmt(state.subtotal)}</span></div>
        <div class="cart-summary-row"><span>Delivery</span><span>Calculated at checkout</span></div>
        <div class="cart-summary-row total"><span>Total</span><span>${fmt(state.subtotal)}</span></div>
        <button type="button" class="btn btn-primary btn-block js-open-checkout">Proceed to Checkout</button>
        <button type="button" class="btn btn-ghost btn-block js-open-whatsapp-order" style="margin-top:10px;">${icon("whatsapp")} Order via WhatsApp</button>
      `;
      foot.querySelector(".js-open-checkout").addEventListener("click", openCheckout);
      foot.querySelector(".js-open-whatsapp-order").addEventListener("click", sendWhatsAppOrder);
    }
  }

  function bumpCartIcon() {
    document.querySelectorAll(".js-cart-count").forEach((el) => {
      el.classList.remove("bump");
      requestAnimationFrame(() => el.classList.add("bump"));
    });
  }

  function initCartDrawer() {
    const overlay = document.querySelector(".js-cart-overlay");
    const drawer = document.querySelector(".js-cart-drawer");
    const openers = document.querySelectorAll(".js-open-cart");
    const closers = document.querySelectorAll(".js-close-cart");

    function open() {
      overlay.classList.add("is-open");
      drawer.classList.add("is-open");
      document.body.style.overflow = "hidden";
    }
    function close() {
      overlay.classList.remove("is-open");
      drawer.classList.remove("is-open");
      document.body.style.overflow = "";
    }

    openers.forEach((btn) => btn.addEventListener("click", open));
    closers.forEach((btn) => btn.addEventListener("click", close));
    overlay.addEventListener("click", close);

    Cart.subscribe(renderCartDrawer);
    renderCartDrawer(Cart.getState());
  }

  /* ---------------------------------------------------------------------- */
  /* WHATSAPP ORDER MESSAGE                                                 */
  /* ---------------------------------------------------------------------- */

  function buildOrderMessage(extra = {}) {
    const state = Cart.getState();
    const b = config.business;
    let msg = `Hello ${b.name}! 👋 I'd like to place an order:\n\n`;
    state.items.forEach((item, i) => {
      msg += `${i + 1}. ${item.name} (${item.unit}) x${item.qty} — ${fmt(item.qty * item.price)}\n`;
    });
    msg += `\nSubtotal: ${fmt(state.subtotal)}`;
    if (extra.deliveryFee !== undefined) {
      msg += `\nDelivery (${extra.deliveryLabel || ""}): ${extra.deliveryFee === 0 ? "Free / Pickup" : fmt(extra.deliveryFee)}`;
      msg += `\nTotal: ${fmt(state.subtotal + extra.deliveryFee)}`;
    }
    if (extra.name) msg += `\n\nName: ${extra.name}`;
    if (extra.phone) msg += `\nPhone: ${extra.phone}`;
    if (extra.address) msg += `\nAddress: ${extra.address}`;
    msg += `\n\nPlease confirm availability. Thank you!`;
    return msg;
  }

  function sendWhatsAppOrder(extra = {}) {
    const state = Cart.getState();
    if (state.items.length === 0) {
      showToast("Add items to your cart first.");
      return;
    }
    const msg = buildOrderMessage(extra);
    const url = `https://wa.me/${config.business.whatsapp}?text=${encodeURIComponent(msg)}`;
    window.open(url, "_blank");
  }

  /* ---------------------------------------------------------------------- */
  /* CHECKOUT MODAL                                                         */
  /* ---------------------------------------------------------------------- */

  function renderDeliveryOptions() {
    const wrap = document.querySelector(".js-delivery-options");
    if (!wrap) return;

    const deliveryOptHTML = `
      <label class="delivery-option ${selectedDeliveryType === "delivery" ? "is-selected" : ""}" data-type="delivery">
        <input type="radio" name="delivery-type" value="delivery" ${selectedDeliveryType === "delivery" ? "checked" : ""}/>
        <span class="opt-text"><strong>Home / Hostel Delivery</strong><span>We bring it to your door</span></span>
        <span class="opt-fee">${fmt(config.deliveryAreas[selectedZoneIndex].fee)}</span>
      </label>
      <label class="delivery-option ${selectedDeliveryType === "pickup" ? "is-selected" : ""}" data-type="pickup">
        <input type="radio" name="delivery-type" value="pickup" ${selectedDeliveryType === "pickup" ? "checked" : ""}/>
        <span class="opt-text"><strong>Self Pickup</strong><span>${config.pickupLocation}</span></span>
        <span class="opt-fee">Free</span>
      </label>
    `;
    wrap.innerHTML = deliveryOptHTML;

    wrap.querySelectorAll(".delivery-option").forEach((opt) => {
      opt.addEventListener("click", () => {
        selectedDeliveryType = opt.dataset.type;
        renderDeliveryOptions();
        renderZoneSelect();
        renderOrderSummary();
        toggleAddressField();
      });
    });

    toggleAddressField();
  }

  function toggleAddressField() {
    const addressGroup = document.querySelector("#address-group");
    if (!addressGroup) return;
    addressGroup.style.display = selectedDeliveryType === "delivery" ? "block" : "none";
  }

  function renderZoneSelect() {
    const wrap = document.querySelector(".js-zone-select");
    if (!wrap) return;
    if (selectedDeliveryType !== "delivery") {
      wrap.style.display = "none";
      return;
    }
    wrap.style.display = "block";
    wrap.innerHTML = `
      <label for="zone-select">Delivery Area</label>
      <select id="zone-select" class="js-zone-dropdown">
        ${config.deliveryAreas
          .map(
            (z, i) =>
              `<option value="${i}" ${i === selectedZoneIndex ? "selected" : ""}>${z.name} — ${fmt(z.fee)} (~${z.etaMinutes} mins)</option>`
          )
          .join("")}
      </select>`;
    wrap.querySelector(".js-zone-dropdown").addEventListener("change", (e) => {
      selectedZoneIndex = parseInt(e.target.value, 10);
      renderDeliveryOptions();
      renderOrderSummary();
    });
  }

  function getCurrentDeliveryFee() {
    if (selectedDeliveryType === "pickup") return 0;
    return config.deliveryAreas[selectedZoneIndex].fee;
  }

  function renderOrderSummary() {
    const box = document.querySelector(".js-order-summary");
    if (!box) return;
    const state = Cart.getState();
    const fee = getCurrentDeliveryFee();
    const zoneName =
      selectedDeliveryType === "pickup" ? "Self Pickup" : config.deliveryAreas[selectedZoneIndex].name;

    box.innerHTML = `
      ${state.items
        .map(
          (i) =>
            `<div class="sum-line"><span>${i.name} x${i.qty}</span><span>${fmt(i.qty * i.price)}</span></div>`
        )
        .join("")}
      <div class="sum-line"><span>Delivery (${zoneName})</span><span>${fee === 0 ? "Free" : fmt(fee)}</span></div>
      <div class="sum-total"><span>Total</span><span>${fmt(state.subtotal + fee)}</span></div>
    `;
  }

  function openCheckout() {
    const state = Cart.getState();
    if (state.items.length === 0) {
      showToast("Your cart is empty.");
      return;
    }
    document.querySelector(".js-cart-overlay")?.classList.remove("is-open");
    document.querySelector(".js-cart-drawer")?.classList.remove("is-open");

    renderDeliveryOptions();
    renderZoneSelect();
    renderOrderSummary();

    const overlay = document.querySelector(".js-checkout-overlay");
    overlay.classList.add("is-open");
    document.body.style.overflow = "hidden";
  }

  function closeCheckout() {
    document.querySelector(".js-checkout-overlay")?.classList.remove("is-open");
    document.body.style.overflow = "";
  }

  function validateCheckoutForm() {
    let valid = true;
    const nameInput = document.querySelector("#checkout-name");
    const phoneInput = document.querySelector("#checkout-phone");
    const addressInput = document.querySelector("#checkout-address");

    [nameInput, phoneInput].forEach((input) => {
      const group = input.closest(".form-group");
      if (!input.value.trim()) {
        group.classList.add("has-error");
        valid = false;
      } else {
        group.classList.remove("has-error");
      }
    });

    if (selectedDeliveryType === "delivery" && addressInput && !addressInput.value.trim()) {
      addressInput.closest(".form-group").classList.add("has-error");
      valid = false;
    } else if (addressInput) {
      addressInput.closest(".form-group").classList.remove("has-error");
    }

    return valid;
  }

  function initCheckoutModal() {
    const overlay = document.querySelector(".js-checkout-overlay");
    if (!overlay) return;

    document.querySelectorAll(".js-close-checkout").forEach((btn) =>
      btn.addEventListener("click", closeCheckout)
    );
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) closeCheckout();
    });

    document.querySelector(".js-checkout-whatsapp-submit")?.addEventListener("click", () => {
      if (!validateCheckoutForm()) {
        showToast("Please fill in the required fields.");
        return;
      }
      const name = document.querySelector("#checkout-name").value.trim();
      const phone = document.querySelector("#checkout-phone").value.trim();
      const address =
        selectedDeliveryType === "delivery" ? document.querySelector("#checkout-address").value.trim() : config.pickupLocation;
      const zoneName =
        selectedDeliveryType === "pickup" ? "Self Pickup" : config.deliveryAreas[selectedZoneIndex].name;

      sendWhatsAppOrder({
        name,
        phone,
        address,
        deliveryFee: getCurrentDeliveryFee(),
        deliveryLabel: zoneName,
      });
      showToast("Order summary sent to WhatsApp!");
    });
  }

  /* ---------------------------------------------------------------------- */
  /* CONTACT FORM (front-end only — no backend wired yet)                  */
  /* ---------------------------------------------------------------------- */

  function initContactForm() {
    const form = document.querySelector(".js-contact-form");
    if (!form) return;
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      showToast("Thanks! Your message has been noted. We'll be in touch soon.");
      form.reset();
    });
  }

  /* ---------------------------------------------------------------------- */
  /* TOAST                                                                  */
  /* ---------------------------------------------------------------------- */

  let toastTimer = null;
  function showToast(message) {
    const toast = document.querySelector(".js-toast");
    if (!toast) return;
    toast.innerHTML = `${icon("check")} <span>${message}</span>`;
    toast.classList.add("is-visible");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("is-visible"), 2800);
  }

  /* ---------------------------------------------------------------------- */
  /* SCROLL REVEAL                                                         */
  /* ---------------------------------------------------------------------- */

  let observer;
  function initReveal(scope = document) {
    if (!observer) {
      observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add("is-visible");
              observer.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.12 }
      );
    }
    scope.querySelectorAll(".reveal:not(.is-visible)").forEach((el) => observer.observe(el));
  }

  /* ---------------------------------------------------------------------- */
  /* INIT                                                                   */
  /* ---------------------------------------------------------------------- */

  async function init() {
    await loadData();
    renderBrandMarks();
    fillBusinessText();
    initNav();
    renderStockWheel();
    renderWhyChooseUs();
    renderCategoryFilters();
    renderProductGrid();
    initShopSearch();
    renderTeam();
    renderTestimonials();
    renderDelivery();
    renderSocial();
    renderContactInfo();
    initCartDrawer();
    initCheckoutModal();
    initContactForm();
    initReveal();

    document.querySelectorAll(".js-whatsapp-cta").forEach((btn) =>
      btn.addEventListener("click", () => sendWhatsAppOrder())
    );

    document.querySelector(".js-shop-now")?.addEventListener("click", () => {
      document.querySelector("#shop")?.scrollIntoView({ behavior: "smooth" });
    });

    document.body.classList.add("is-ready");
  }

  return { init };
})();

document.addEventListener("DOMContentLoaded", App.init);
